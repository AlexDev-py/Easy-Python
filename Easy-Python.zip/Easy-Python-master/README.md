# Easy-Python
Проект IT fest 2020

# Запуск

[Скачать git](https://git-scm.com/downloads)

```bash
git clone https://github.com/AlexDev-py/Easy-Python.git
cd Easy-Python
python -m venv venv
venv\Scripts\activate.bat
pip install -r requirements.txt
python main.py
```

